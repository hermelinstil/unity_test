﻿using UnityEngine;
using System.Collections;

public interface Ability {

	void execute();
}
