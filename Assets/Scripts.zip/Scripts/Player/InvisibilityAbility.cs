﻿using UnityEngine;
using System.Collections;

public class InvisibilityAbility : Ability {



	public InvisibilityAbility() {

	}

	public void execute() {

	}
}
